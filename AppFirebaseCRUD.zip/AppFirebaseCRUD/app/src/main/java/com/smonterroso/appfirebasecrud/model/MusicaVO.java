package com.smonterroso.appfirebasecrud.model;

public class MusicaVO {

    private String id;
    private String nombre, album, artista, genero;

    public MusicaVO(){

    }

    public MusicaVO(String id, String nombre, String album, String artista, String genero) {
        this.id = id;
        this.nombre = nombre;
        this.album = album;
        this.artista = artista;
        this.genero = genero;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getAlbum() {
        return album;
    }

    public void setAlbum(String album) {
        this.album = album;
    }

    public String getArtista() {
        return artista;
    }

    public void setArtista(String artista) {
        this.artista = artista;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    @Override
    public String toString() {

        return nombre;

    }


}
