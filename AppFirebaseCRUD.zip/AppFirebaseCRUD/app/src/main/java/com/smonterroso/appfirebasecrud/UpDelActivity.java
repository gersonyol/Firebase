package com.smonterroso.appfirebasecrud;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.smonterroso.appfirebasecrud.model.MusicaVO;

public class UpDelActivity extends AppCompatActivity {

    private EditText txtN, txtAl, txtAr, txtG;
    private String idT, nom, al, ar, gen;

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    MusicaVO mvo = new MusicaVO();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_up_del);

        txtN = findViewById(R.id.txtNomCUD);
        txtAl = findViewById(R.id.txtAlbumUD);
        txtAr = findViewById(R.id.txtArtistUD);
        txtG = findViewById(R.id.txtGenUD);

        iniciarFirebase();
        datosRecibidos();


    }

    public void onClick(View view) {

        switch(view.getId()){
            case R.id.btnActualizar:
                update();
                break;

            case R.id.btnEliminar:
                delete();
                break;

        }

    }

    private void iniciarFirebase(){
        FirebaseApp.initializeApp(getApplicationContext());
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();

    }

    private void datosRecibidos(){

        Bundle bundle = getIntent().getExtras();
        idT = bundle.getString("id");
        nom = bundle.getString("nombre");
        al = bundle.getString("album");
        ar = bundle.getString("artista");
        gen = bundle.getString("genero");

        txtN.setText(nom);
        txtAl.setText(al);
        txtAr.setText(ar);
        txtG.setText(gen);

    }

    private void update (){
        if (!txtN.getText().toString().isEmpty() && !txtAl.getText().toString().isEmpty() && !txtAr.getText().toString().isEmpty() && !txtG.getText().toString().isEmpty()){
            mvo.setId(idT);
            mvo.setNombre(txtN.getText().toString());
            mvo.setAlbum(txtAl.getText().toString());
            mvo.setArtista(txtAr.getText().toString());
            mvo.setGenero(txtG.getText().toString());

            databaseReference.child("Musica").child(mvo.getId()).setValue(mvo);

            Toast.makeText(this, "Actulizado correctamente", Toast.LENGTH_SHORT).show();

        }else{
            Toast.makeText(this, "Datos no actualizados", Toast.LENGTH_SHORT).show();
        }


    }

    private void delete(){

        if (!txtN.getText().toString().isEmpty() && !txtAl.getText().toString().isEmpty() && !txtAr.getText().toString().isEmpty() && !txtG.getText().toString().isEmpty()){

            mvo.setId(idT);
            databaseReference.child("Musica").child(mvo.getId()).removeValue();

            txtN.setText("");
            txtAl.setText("");
            txtAr.setText("");
            txtG.setText("");
            Toast.makeText(this, "Eliminado correctamente", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(this, "Datos no eliminados", Toast.LENGTH_SHORT).show();
        }

    }


}
