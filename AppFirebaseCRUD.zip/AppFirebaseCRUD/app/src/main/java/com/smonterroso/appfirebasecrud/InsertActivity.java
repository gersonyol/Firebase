
package com.smonterroso.appfirebasecrud;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.smonterroso.appfirebasecrud.model.MusicaVO;

import java.util.UUID;

public class InsertActivity extends AppCompatActivity {

    private EditText txtN, txtAl, txtAr, txtG;

    //Variables para la interacción con RealTime en Firebase
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);

        txtN = findViewById(R.id.txtNomC);
        txtAl = findViewById(R.id.txtAlbum);
        txtAr = findViewById(R.id.txtArtist);
        txtG = findViewById(R.id.txtGen);

        iniciarFirebase();


    }


    public void onClick(View view) {
        insert();
    }

    private void iniciarFirebase(){
        FirebaseApp.initializeApp(getApplicationContext());
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();

    }

    private void insert(){

        MusicaVO mvo = new MusicaVO();
        if (!txtN.getText().toString().isEmpty()&&!txtAl.getText().toString().isEmpty()&&!txtAr.getText().toString().isEmpty()&&!txtG.getText().toString().isEmpty()){
            mvo.setId(UUID.randomUUID().toString());
            mvo.setNombre(txtN.getText().toString());
            mvo.setAlbum(txtAl.getText().toString());
            mvo.setArtista(txtAr.getText().toString());
            mvo.setGenero(txtG.getText().toString());

            //Creación del nodo, tabla o child con sus clave-valor referentes en Firebase
            databaseReference.child("Musica").child(mvo.getId()).setValue(mvo);
            txtN.setText("");
            txtAl.setText("");
            txtAr.setText("");
            txtG.setText("");

            Toast.makeText(this, "Datos ingresados correctamente", Toast.LENGTH_SHORT).show();

        }else{

            Toast.makeText(this, "Datos no ingresados", Toast.LENGTH_SHORT).show();

        }

    }




}
